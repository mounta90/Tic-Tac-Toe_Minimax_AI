import math
from tkinter import *

window = Tk()

window.geometry("500x500")
window.title("Tic Tac Toe")
window.iconbitmap(r'Resources\\tic-tac-toe.ico')
window.config(background="black")

# --------BEGINNING OF frame declaration-----------#

# Parent Frame
parentFrame = Frame(window, bg="white", height="300", width="300")
parentFrame.place(relx=.5, rely=.5, anchor=CENTER)
# Parent Frame

# Child Frames
childFrames = []                                     
childFrames_row0 = []
childFrames_row1 = []
childFrames_row2 = []

childFrames.append(childFrames_row0)
childFrames.append(childFrames_row1)
childFrames.append(childFrames_row2)

# Initialize the 3x3 board to all spots available
availableBoardSpots = [(0,0), (0,1), (0,2), (1,0), (1,1), (1,2), (2,0), (2,1), (2,2)]
# Initialize the 3x3 board to all spots available

childFrame00 = Frame(parentFrame, name='cF00', bg='white', height="100", width="100", highlightbackground='black', highlightthickness=2)
childFrame00.grid(row=0, column=0)
childFrames_row0.append({'cF': childFrame00, 'filled': None})

childFrame01 = Frame(parentFrame, name='cF01', bg='white', height="100", width="100", highlightbackground='black', highlightthickness=2)
childFrame01.grid(row=0, column=1)
childFrames_row0.append({'cF': childFrame01, 'filled': None})

childFrame02 = Frame(parentFrame, name='cF02', bg='white', height="100", width="100", highlightbackground='black', highlightthickness=2)
childFrame02.grid(row=0, column=2)
childFrames_row0.append({'cF': childFrame02, 'filled': None})

childFrame10 = Frame(parentFrame, name='cF10', bg='white', height="100", width="100", highlightbackground='black', highlightthickness=2)
childFrame10.grid(row=1, column=0)
childFrames_row1.append({'cF': childFrame10, 'filled': None})

childFrame11 = Frame(parentFrame, name='cF11', bg='white', height="100", width="100", highlightbackground='black', highlightthickness=2)
childFrame11.grid(row=1, column=1)
childFrames_row1.append({'cF': childFrame11, 'filled': None})

childFrame12 = Frame(parentFrame, name='cF12', bg='white', height="100", width="100", highlightbackground='black', highlightthickness=2)
childFrame12.grid(row=1, column=2)
childFrames_row1.append({'cF': childFrame12, 'filled': None})

childFrame20 = Frame(parentFrame, name='cF20', bg='white', height="100", width="100", highlightbackground='black', highlightthickness=2)
childFrame20.grid(row=2, column=0)
childFrames_row2.append({'cF': childFrame20, 'filled': None})

childFrame21 = Frame(parentFrame, name='cF21', bg='white', height="100", width="100", highlightbackground='black', highlightthickness=2)
childFrame21.grid(row=2, column=1)
childFrames_row2.append({'cF': childFrame21, 'filled': None})

childFrame22 = Frame(parentFrame, name='cF22', bg='white', height="100", width="100", highlightbackground='black', highlightthickness=2)
childFrame22.grid(row=2, column=2)
childFrames_row2.append({'cF': childFrame22, 'filled': None})
# Child Frames



# ----------END OF frame declaration------------ #


# Game Label
gameLabel = Label(window,
                text=f"Tic Tac Toe",
                font=("Arial", 25),
                bg="black",
                fg='#0FFF50')       
gameLabel.pack(side=TOP, pady=25)
# Game Label


# ---------------BEGINNING OF game functions--------------- #
#a==b and b==c and c !== ""
def checkRow0(row0arr):
    # Row 0
    row0Result = row0arr[0] == row0arr[1] and row0arr[1] == row0arr[2] and not (row0arr[2] == None)

    return row0Result

def checkRow1(row1arr):
    # Row 1
    row1Result = row1arr[0] == row1arr[1] and row1arr[1] == row1arr[2] and not (row1arr[2] == None)

    return row1Result

def checkRow2(row2arr):
    # Row 2
    row2Result = row2arr[0] == row2arr[1] and row2arr[1] == row2arr[2] and not (row2arr[2] == None)

    return row2Result
    


def checkColumn0(column0arr):
    # Column 0
    column0Result = column0arr[0] == column0arr[1] and column0arr[1] == column0arr[2] and not (column0arr[2] == None)

    return column0Result

def checkColumn1(column1arr):
    # Column 1
    column1Result = column1arr[0] == column1arr[1] and column1arr[1] == column1arr[2] and not (column1arr[2] == None)

    return column1Result

def checkColumn2(column2arr):
    # Column 2
    column2Result = column2arr[0] == column2arr[1] and column2arr[1] == column2arr[2] and not (column2arr[2] == None)

    return column2Result

def checkDiagnols(gameArr):
    # Check the 2 diagnols for either: all HUMAN or all AI

    # Top left to bottom right
    diagnol1Result = gameArr[0][0] == gameArr[1][1] and gameArr[1][1] == gameArr[2][2] and not (gameArr[2][2] == None)

    # Top right to bottom left
    diagnol2Result = gameArr[0][2] == gameArr[1][1] and gameArr[1][1] == gameArr[2][0] and not (gameArr[2][0] == None)

    return (diagnol1Result or diagnol2Result)


def displayResult(winner):

    result = f'{winner} won'

    if winner == "TIE":
        result = winner

    gameResult = Label(window,
                text=f"Result - {result}",
                font=("Arial", 20),
                bg="black",
                fg="white")       
    gameResult.pack(side=BOTTOM, pady=25)

def enterChildFrame(event):
    frame = event.widget    #the widget which is hovered over by mouse
    cf_row = int(str(frame)[-2]) #gets the row number
    cf_col = int(str(frame)[-1]) #gets the column number

    if childFrames[cf_row][cf_col]['filled'] == None:
        print(f"Hovered over {cf_row}, {cf_col}")
        frame.config(cursor='circle')
        frame['bg'] = 'blue'
    else:
        frame.config(cursor='arrow')


def leaveChildFrame(event):
    frame = event.widget
    frame['bg'] = 'white'


for row in range(len(childFrames)):
    for col in range(len(childFrames)):
        if childFrames[row][col]['filled'] == None:
            childFrames[row][col]['cF'].bind("<Enter>", enterChildFrame)
            childFrames[row][col]['cF'].bind("<Leave>", leaveChildFrame)
        else:
            childFrames[row][col]['cF'].unbind_class("<Enter>", "<Leave>")
    

def place_O(event):
    frame = event.widget    #the widget which is hovered over by mouse
    cf_row = int(str(frame)[-2]) #gets the row number
    cf_col = int(str(frame)[-1]) #gets the column number

    canvas = Canvas(parentFrame, height='90', width='90', bg='white')
    canvas.grid(row=cf_row, column=cf_col)
    canvas.create_oval(10, 10, 80, 80, outline='blue', width=2)

    childFrames[cf_row][cf_col]['filled'] = "HUMAN"
    availableBoardSpots.remove((cf_row, cf_col))
    print(availableBoardSpots)

    #checks if there is winner
    thereIsWinner = checkRow0([square['filled'] for square in childFrames[0]]) or checkRow1([square['filled'] for square in childFrames[1]]) or checkRow2([square['filled'] for square in childFrames[2]]) or checkColumn0([childFrames[0][0]['filled'], childFrames[1][0]['filled'], childFrames[2][0]['filled']]) or checkColumn1([childFrames[0][1]['filled'], childFrames[1][1]['filled'], childFrames[2][1]['filled']]) or checkColumn2([childFrames[0][2]['filled'], childFrames[1][2]['filled'], childFrames[2][2]['filled']]) or checkDiagnols([[childFrames[0][0]['filled'], childFrames[0][1]['filled'], childFrames[0][2]['filled']], [childFrames[1][0]['filled'], childFrames[1][1]['filled'], childFrames[1][2]['filled']], [childFrames[2][0]['filled'], childFrames[2][1]['filled'], childFrames[2][2]['filled']]])

    winner = 'TIE'

    #checks for who the winner is
    if checkRow0([square['filled'] for square in childFrames[0]]):
        winner = childFrames[0][0]['filled']
    elif checkRow1([square['filled'] for square in childFrames[1]]):
        winner = childFrames[1][0]['filled']
    elif checkRow2([square['filled'] for square in childFrames[2]]):
        winner = childFrames[2][0]['filled']
    elif checkColumn0([childFrames[0][0]['filled'], childFrames[1][0]['filled'], childFrames[2][0]['filled']]):
        winner = childFrames[0][0]['filled']
    elif checkColumn1([childFrames[0][1]['filled'], childFrames[1][1]['filled'], childFrames[2][1]['filled']]):
        winner = childFrames[0][1]['filled']
    elif checkColumn2([childFrames[0][2]['filled'], childFrames[1][2]['filled'], childFrames[2][2]['filled']]):
        winner = childFrames[0][2]['filled']
    elif checkDiagnols([[childFrames[0][0]['filled'], childFrames[0][1]['filled'], childFrames[0][2]['filled']], [childFrames[1][0]['filled'], childFrames[1][1]['filled'], childFrames[1][2]['filled']], [childFrames[2][0]['filled'], childFrames[2][1]['filled'], childFrames[2][2]['filled']]]):
        winner = childFrames[1][1]['filled']

    print(thereIsWinner)
    if (len(availableBoardSpots) > 0) and (not thereIsWinner):
        play_AI()
    else:
        displayResult(winner)


for row in range(len(childFrames)):
    for col in range(len(childFrames)):
        if childFrames[row][col]['filled'] == None:
            childFrames[row][col]['cF'].bind("<Button-1>", place_O)
        else:
            childFrames[row][col]['cF'].unbind("<Button-1>")


def getNextMove():

    nextMoveScore = math.inf #since AI is a minimizer
    
    avBoardSpots = availableBoardSpots.copy()

    gameBoard = [
        [childFrames[0][0]['filled'], childFrames[0][1]['filled'], childFrames[0][2]['filled']],
        [childFrames[1][0]['filled'], childFrames[1][1]['filled'], childFrames[1][2]['filled']],
        [childFrames[2][0]['filled'], childFrames[2][1]['filled'], childFrames[2][2]['filled']]
    ]
    
    for spot in availableBoardSpots:
        row = spot[0]
        column = spot[1]
        gameBoard[row][column] = "AI"
        avBoardSpots.remove((row, column))

        score = minimax(True, avBoardSpots, gameBoard)

        print(f"from getNextMove(): nextMove = ({row}, {column}) nextMoveScore = {nextMoveScore}, score = {score}")

        gameBoard[row][column] = None
        avBoardSpots.append((row, column))

        if score < nextMoveScore:
            nextMoveScore = score
            nextMove = (row, column)
    
    print(availableBoardSpots)
    
    childFrames[nextMove[0]][nextMove[1]]['filled'] = "AI"
    availableBoardSpots.remove((nextMove[0], nextMove[1]))

    return nextMove[0], nextMove[1]




def minimax(isMaximizing, avBoardSpots, gameBoard):
    # base case (terminal state): if winner has value, return score

    #checks for winner
    thereIsWinner = checkRow0([gameBoard[0][0], gameBoard[0][1], gameBoard[0][2]]) or checkRow1([gameBoard[1][0], gameBoard[1][1], gameBoard[1][2]]) or checkRow2([gameBoard[2][0], gameBoard[2][1], gameBoard[2][2]]) or checkColumn0([gameBoard[0][0], gameBoard[1][0], gameBoard[2][0]]) or checkColumn1([gameBoard[0][1], gameBoard[1][1], gameBoard[2][1]]) or checkColumn2([gameBoard[0][2], gameBoard[1][2], gameBoard[2][2]]) or checkDiagnols(gameBoard)

    winner = 'TIE'

    #checks who is winner
    if checkRow0([gameBoard[0][0], gameBoard[0][1], gameBoard[0][2]]):
        winner = gameBoard[0][0]
    elif checkRow1([gameBoard[1][0], gameBoard[1][1], gameBoard[1][2]]):
        winner = gameBoard[1][0]
    elif checkRow2([square['filled'] for square in childFrames[2]]):
        winner = gameBoard[2][0]
    elif checkColumn0([gameBoard[0][0], gameBoard[1][0], gameBoard[2][0]]):
        winner = gameBoard[0][0]
    elif checkColumn1([gameBoard[0][1], gameBoard[1][1], gameBoard[2][1]]):
        winner = gameBoard[0][1]
    elif checkColumn2([gameBoard[0][2], gameBoard[1][2], gameBoard[2][2]]):
        winner = gameBoard[0][2]
    elif checkDiagnols(gameBoard):
        winner = gameBoard[1][1]
    
    if thereIsWinner:
        if winner == "AI":
            return -1
        elif winner == "HUMAN":
            return 1

    elif len(avBoardSpots) == 0:
        return 0
    
    #-----------END OF BASE CASE----------#
    
    if isMaximizing:
        maximizerScore = -math.inf
        for spot in avBoardSpots:
            row = spot[0]
            column = spot[1]
            gameBoard[row][column] = "HUMAN"
            avBoardSpots.remove((row, column))
            score = minimax(False, avBoardSpots, gameBoard)

            gameBoard[row][column] = None
            avBoardSpots.append((row, column))

            maximizerScore = max(maximizerScore, score)

        return maximizerScore


    else:
        minimizerScore = math.inf    
        for spot in avBoardSpots:
            row = spot[0]
            column = spot[1]
            gameBoard[row][column] = "AI"
            avBoardSpots.remove((row, column))
            score = minimax(True, avBoardSpots, gameBoard)

            gameBoard[row][column] = None
            avBoardSpots.append((row, column))

            minimizerScore = min(minimizerScore, score)
        
        return minimizerScore
    

def play_AI():

    nextRow, nextColumn = getNextMove()

    canvas = Canvas(parentFrame, height='90', width='90', bg='white')
    canvas.grid(row=nextRow, column=nextColumn)
    canvas.create_line(10, 10, 80, 80, fill='red', width=2)
    canvas.create_line(10, 80, 80, 10, fill='red', width=2)

    print(availableBoardSpots)

    thereIsWinner = checkRow0([square['filled'] for square in childFrames[0]]) or checkRow1([square['filled'] for square in childFrames[1]]) or checkRow2([square['filled'] for square in childFrames[2]]) or checkColumn0([childFrames[0][0]['filled'], childFrames[1][0]['filled'], childFrames[2][0]['filled']]) or checkColumn1([childFrames[0][1]['filled'], childFrames[1][1]['filled'], childFrames[2][1]['filled']]) or checkColumn2([childFrames[0][2]['filled'], childFrames[1][2]['filled'], childFrames[2][2]['filled']]) or checkDiagnols([[childFrames[0][0]['filled'], childFrames[0][1]['filled'], childFrames[0][2]['filled']], [childFrames[1][0]['filled'], childFrames[1][1]['filled'], childFrames[1][2]['filled']], [childFrames[2][0]['filled'], childFrames[2][1]['filled'], childFrames[2][2]['filled']]])

    winner = 'TIE'

    if checkRow0([square['filled'] for square in childFrames[0]]):
        winner = childFrames[0][0]['filled']
    elif checkRow1([square['filled'] for square in childFrames[1]]):
        winner = childFrames[1][0]['filled']
    elif checkRow2([square['filled'] for square in childFrames[2]]):
        winner = childFrames[2][0]['filled']
    elif checkColumn0([childFrames[0][0]['filled'], childFrames[1][0]['filled'], childFrames[2][0]['filled']]):
        winner = childFrames[0][0]['filled']
    elif checkColumn1([childFrames[0][1]['filled'], childFrames[1][1]['filled'], childFrames[2][1]['filled']]):
        winner = childFrames[0][1]['filled']
    elif checkColumn2([childFrames[0][2]['filled'], childFrames[1][2]['filled'], childFrames[2][2]['filled']]):
        winner = childFrames[0][2]['filled']
    elif checkDiagnols([[childFrames[0][0]['filled'], childFrames[0][1]['filled'], childFrames[0][2]['filled']], [childFrames[1][0]['filled'], childFrames[1][1]['filled'], childFrames[1][2]['filled']], [childFrames[2][0]['filled'], childFrames[2][1]['filled'], childFrames[2][2]['filled']]]):
        winner = childFrames[1][1]['filled']

    print(thereIsWinner)
    if thereIsWinner:
        displayResult(winner)

# -------------ENDING OF game functions------------ #

window.mainloop()